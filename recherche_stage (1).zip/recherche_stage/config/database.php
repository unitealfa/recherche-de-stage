<?php

$DB_NAME = 'meow_stage';
$DB_USER = 'root';
$DB_PASS = 'Canva-chan';

try {
    $db = new PDO('mysql:host=localhost;dbname=' . $DB_NAME, $DB_USER, $DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
