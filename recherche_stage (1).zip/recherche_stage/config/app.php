<?php

define('BASE_URL', 'http://elka_stage.org/');
