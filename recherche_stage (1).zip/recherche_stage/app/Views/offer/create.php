<?php include "app/Views/layout/header.php"; ?>

<link rel="stylesheet" type="text/css" href="public/css/OffreCreate.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

<h2>Créer une offre de stage</h2>

<?php if(isset($error)): ?>
    <p style="color:red;"><?= $error; ?></p>
<?php endif; ?>

<form method="post" action="index.php?controller=offer&action=create" enctype="multipart/form-data">
    <div class="form-container">
        <div class="form-group">
            <label>Entreprise</label>
            <select name="company_id" required>
                <option value="">Sélectionnez une entreprise</option>
                <?php foreach ($companies as $company): ?>
                    <option value="<?= htmlspecialchars($company['company_id']); ?>">
                        <?= htmlspecialchars($company['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-row">
            <div class="form-group form-half">
                <label>Titre</label>
                <input type="text" name="title" placeholder="Stage en quoi ?" required>
            </div>
            <div class="form-group form-half">
                <label>Description</label>
                <textarea name="description" placeholder="Entrez la description" required></textarea>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group form-half">
                <label>Compétences</label>
                <input type="text" name="competencies" placeholder="Entrez les compétences">
            </div>
            <div class="form-group form-half">
                <label>Rémunération</label>
                <input type="number" step="0.01" name="remuneration_base" placeholder="Entrez la rémunération">
            </div>
        </div>

        <div class="calendar-row">
            <div class="calendar-box">
                <label>Date de début</label>
                <input type="text" name="start_date" id="start-date" class="flatpickr-input" style="display: none;">
                <div id="start-date-inline"></div>
            </div>
            <div class="calendar-box">
                <label>Date de fin</label>
                <input type="text" name="end_date" id="end-date" class="flatpickr-input" style="display: none;">
                <div id="end-date-inline"></div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit">Créer l'offre</button>
        </div>
    </div>
</form>



<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    flatpickr("#start-date", {
        inline: true,
        dateFormat: "Y-m-d",
        defaultDate: "2025-03-14",
        appendTo: document.getElementById('start-date-inline')
    });

    flatpickr("#end-date", {
        inline: true,
        dateFormat: "Y-m-d",
        defaultDate: "2025-03-22",
        appendTo: document.getElementById('end-date-inline')
    });
</script>

<?php include "app/Views/layout/footer.php"; ?>
