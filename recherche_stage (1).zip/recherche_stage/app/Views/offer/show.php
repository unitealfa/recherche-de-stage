<?php include "app/Views/layout/header.php"; ?>

<link rel="stylesheet" type="text/css" href="public/css/OffreShow.css">

<div class="offer-container">
    <h2>Détails de l'Offre</h2>

    <div class="offer-info">
        <div class="info-group">
            <label>Titre</label>
            <p><?= htmlspecialchars($offer['title']); ?></p>
        </div>

        <div class="info-group">
            <label>Description</label>
            <p><?= htmlspecialchars($offer['description'] ?? 'Non renseigné'); ?></p>
        </div>

        <div class="info-group">
            <label>Compétences</label>
            <p><?= htmlspecialchars($offer['competencies'] ?? 'Non renseigné'); ?></p>
        </div>

        <div class="info-group">
            <label>Rémunération</label>
            <p><?= htmlspecialchars($offer['remuneration_base'] ?? ''); ?></p>
        </div>

        <div class="info-group">
            <label>Date de début</label>
            <p><?= htmlspecialchars($offer['start_date'] ?? ''); ?></p>
        </div>

        <div class="info-group">
            <label>Date de fin</label>
            <p><?= htmlspecialchars($offer['end_date'] ?? ''); ?></p>
        </div>
    </div>

    <div class="link-button">
        <a href="index.php?controller=company&action=show&id=<?= htmlspecialchars($offer['company_id']); ?>">Consulter l'entreprise</a>
    </div>
</div>



<?php include "app/Views/layout/footer.php"; ?>
