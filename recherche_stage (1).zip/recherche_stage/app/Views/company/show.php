<?php include "app/Views/layout/header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Détails de l'entreprise</title>
    <link rel="stylesheet" type="text/css" href="Public/css/CompanyShow.css">
</head>
<body>
    <h2>Détails de l'entreprise</h2>

    <div class="info-container">
        <div class="image-display">
            <div class="preview" style="background-image: url('public/uploads/companies/<?= htmlspecialchars($company['profile_picture'] ?? 'default_pfp.png'); ?>');"></div>
        </div>

        <div class="details">
            <div class="detail-row">
                <div class="detail-group">
                    <label>Nom</label>
                    <p><?= htmlspecialchars($company['name']); ?></p>
                </div>
                <div class="detail-group">
                    <label>Téléphone</label>
                    <p><?= htmlspecialchars($company['phone_contact'] ?? 'Non renseigné'); ?></p>
                </div>
            </div>

            <div class="detail-row">
                <div class="detail-group">
                    <label>Email</label>
                    <p><?= htmlspecialchars($company['email_contact'] ?? 'Non renseigné'); ?></p>
                </div>
                <div class="detail-group">
                    <label>Description</label>
                    <p><?= htmlspecialchars($company['description'] ?? 'Non renseigné'); ?></p>
                </div>
            </div>

            <div class="detail-group">
                <label>Note moyenne</label>
                <p><?= htmlspecialchars($company['average_rating'] ?? 'Non notée'); ?></p>
            </div>

            <?php if (isset($_SESSION['user']) && in_array(strtoupper($_SESSION['user']['role']), ['ADMIN', 'PILOTE', 'ETUDIANT'])): ?>
                <div class="rating-section">
                    <label>Évaluer l'entreprise</label>
                    <?php if(isset($error)): ?>
                        <p style="color:red;"><?= $error; ?></p>
                    <?php endif; ?>
                    <form method="post" action="index.php?controller=company&action=evaluate">
                        <input type="hidden" name="company_id" value="<?= htmlspecialchars($company['company_id']); ?>">
                        <div class="stars" id="star-rating">
                            <?php for ($i = 5; $i >= 1; $i--): ?>
                                <span data-value="<?= $i; ?>">★</span>
                            <?php endfor; ?>
                        </div>
                        <button type="submit" class="submit-btn">Envoyer l'évaluation</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="return-btn" onclick="history.back()">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="48" height="48" fill="white" fill-opacity="0.01"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M44 40.8361C39.1069 34.8632 34.7617 31.4739 30.9644 30.6682C27.1671 29.8625 23.5517 29.7408 20.1182 30.303V41L4 23.5453L20.1182 7V17.167C26.4667 17.2172 31.8638 19.4948 36.3095 24C40.7553 28.5052 43.3187 34.1172 44 40.8361Z" fill="#FF43DD" stroke="#000000" stroke-width="4" stroke-linejoin="round"/>
        </svg>
    </div>

    <script>
        const stars = document.querySelectorAll("#star-rating span");
        let selectedRating = 0;

        stars.forEach((star) => {
            star.addEventListener("click", () => {
                selectedRating = parseInt(star.getAttribute("data-value"));

                stars.forEach((s) => {
                    if (parseInt(s.getAttribute("data-value")) <= selectedRating) {
                        s.classList.add("active");
                    } else {
                        s.classList.remove("active");
                    }
                });
            });
        });
    </script>
</body>
</html>

<?php include "app/Views/layout/footer.php"; ?>
