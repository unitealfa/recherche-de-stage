<?php include "app/Views/layout/header.php"; ?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <title>
    <?php
      $editing = (isset($company) && is_array($company));
      echo $editing ? "Modifier l'entreprise" : "Créer une entreprise";
    ?>
  </title>
  <link rel="stylesheet" type="text/css" href="public/css/CompanyEdit.css">
</head>
<body>

<h2>
  <?= $editing ? "Modifier l'entreprise" : "Créer une entreprise"; ?>
</h2>

<?php if (isset($error)): ?>
  <p style="color:red;"><?= htmlspecialchars($error); ?></p>
<?php endif; ?>

<?php
$companyId     = $editing ? ($company['company_id']       ?? '') : '';
$profilePic    = $editing ? ($company['profile_picture']  ?? 'public/uploads/companies/default_pfp.png')
                          : 'public/uploads/companies/default_pfp.png';
$name          = $editing ? ($company['name']             ?? '') : '';
$description   = $editing ? ($company['description']      ?? '') : '';
$email_contact = $editing ? ($company['email_contact']    ?? '') : '';
$phone_contact = $editing ? ($company['phone_contact']    ?? '') : '';
?>


<form
  method="post"
  action="index.php?controller=company&action=<?= $editing ? 'edit' : 'create'; ?>"
  enctype="multipart/form-data"
>
  <div class="form-container">

    <div class="image-upload">
      <!-- Affichage d’un aperçu (background) ou fallback -->
      <div class="preview" style="background-image: url('<?= htmlspecialchars($profilePic) ?>');"></div>

      <!-- Custom link to trigger file explorer -->
      <label for="profile_picture_input" class="upload-link" style="cursor: pointer;">Upload a Photo</label>
      <input type="file" name="profile_picture" id="profile_picture_input" accept="image/*" style="display: none;">
    </div>

    <div class="form-fields">
      <div class="form-group-row">
        <div class="form-group">
          <label>Nom</label>
          <input
            type="text"
            name="name"
            value="<?= htmlspecialchars($name) ?>"
            placeholder="Nom de l'entreprise"
            required
          />
        </div>

        <div class="form-group">
          <label>Téléphone</label>
          <input
            type="text"
            name="phone_contact"
            value="<?= htmlspecialchars($phone_contact) ?>"
            placeholder="Numéro de téléphone"
          />
        </div>
      </div>

      <div class="form-group-row">
        <div class="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email_contact"
            value="<?= htmlspecialchars($email_contact) ?>"
            placeholder="Adresse email"
            required
          />
        </div>

        <div class="form-group">
          <label>Description</label>
          <textarea
            name="description"
            placeholder="Décrivez l'entreprise"
            required
          ><?= htmlspecialchars($description) ?></textarea>
        </div>
      </div>

      <!-- Si on édite, on envoie aussi l'ID et l’existant -->
      <?php if ($editing): ?>
        <input
          type="hidden"
          name="id"
          value="<?= htmlspecialchars($companyId) ?>"
        >
        <input
          type="hidden"
          name="existing_profile_picture"
          value="<?= htmlspecialchars($profilePic) ?>"
        >
      <?php endif; ?>

      <div class="form-actions">
        <button type="submit">
          <?= $editing ? "Modifier" : "Créer"; ?>
        </button>
      </div>
    </div> <!-- end .form-fields -->

  </div> <!-- end .form-container -->
</form>

<!-- Lien de retour -->
<a href="index.php?controller=company&action=index">Retour</a>

<!-- SVG décoratif ou bouton forward -->
<div class="custom-forward-icon">
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" fill="white" fill-opacity="0.01"/>
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M44 40.8361C39.1069 34.8632 34.7617 31.4739 30.9644 30.6682C27.1671 29.8625 23.5517 29.7408 20.1182 30.303V41L4 23.5453L20.1182 7V17.167C26.4667 17.2172 31.8638 19.4948 36.3095 24C40.7553 28.5052 43.3187 34.1172 44 40.8361Z"
      fill="#FF43DD" stroke="#000000" stroke-width="4" stroke-linejoin="round"
    />
  </svg>
</div>

<script>
  // No need for file-chosen script since the placeholder has been removed.
</script>

</body>
</html>

<?php include "app/Views/layout/footer.php"; ?>
