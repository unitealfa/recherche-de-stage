<?php include "app/Views/layout/header.php"; ?>
<h2>Erreur 403 - Accès interdit</h2>
<p>Vous n'êtes pas autorisé à accéder à cette page.</p>
<a href="index.php">Retour à l'accueil</a>
<?php include "app/Views/layout/footer.php"; ?>
