<?php include "app/Views/layout/header.php"; ?>
<h2>Erreur 404 - Page non trouvée</h2>
<p>La page que vous recherchez n'existe pas.</p>
<a href="index.php">Retour à l'accueil</a>
<?php include "app/Views/layout/footer.php"; ?>
