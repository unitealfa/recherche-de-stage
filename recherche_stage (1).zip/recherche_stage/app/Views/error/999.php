<?php include "app/Views/layout/header.php"; ?>
<h2>Erreur 999</h2>
<p>Vous avez essayé de consulter un utilisateur Admin, </p>
<p>Veuillez revenir à la liste des utilisateurs.</p>
<a href="index.php?controller=user&action=index">Retour</a>
<?php include "app/Views/layout/footer.php"; ?>
