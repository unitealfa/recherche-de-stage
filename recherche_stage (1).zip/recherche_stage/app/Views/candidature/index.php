<?php include "app/Views/layout/header.php"; ?>

<!-- Lien vers la feuille de style Candidatures -->
<link rel="stylesheet" href="public/css/Candidatures.css">
<style>
    /* ====== PAGINATION ====== */
.pagination {
  margin-top: 1rem;
  display: flex;
  gap: 0.4rem;
  align-items: center;
  justify-content: center; /* Centrer la pagination */
}

.pagination a,
.pagination strong {
  text-decoration: none;
  color: #fff;
  background-color: #2C3039;
  border-radius: 5px;
  padding: 0.5rem 0.9rem;
  border: 1px solid #3A4049;
  font-size: 0.9rem;
  transition: background-color 0.2s ease;
}

.pagination a:hover {
  background-color: #3A4049;
}

/* Bouton actif (numéro de page courant) */
.pagination strong {
  color: #FF43DD; /* Rose, pour se démarquer */
  border-color: #FF43DD;
  background-color: #3A4049;
}

</style>

<h1>Candidatures</h1>

<!-- Affichage des éventuelles erreurs -->
<?php if (isset($error)): ?>
    <p class="error-message"><?= htmlspecialchars($error); ?></p>
<?php endif; ?>

<?php 
// Récupérer le rôle de l'utilisateur depuis la session
$userRole = strtoupper($_SESSION['user']['role'] ?? '');
?>

<!-- Bouton d'ajout de candidature (ETUDIANT) ou d'offre (PILOTE) -->


<!-- Tableau stylé -->
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Offre</th>
                <?php if ($userRole === 'ADMIN' || $userRole === 'PILOTE'): ?>
                    <th>Nom</th>
                <?php endif; ?>
                <th>Lettre de motivation</th>
                <th>CV</th>
                <th>Entreprise</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($candidatures as $candidature): ?>
            <tr>
                <!-- Offre -->
                <td><?= htmlspecialchars($candidature['offer_title'] ?? 'Non renseigné'); ?></td>

                <!-- Nom (seulement si ADMIN/PILOTE) -->
                <?php if ($userRole === 'ADMIN' || $userRole === 'PILOTE'): ?>
                    <td><?= htmlspecialchars($candidature['candidate_name'] ?? 'Non renseigné'); ?></td>
                <?php endif; ?>

                <!-- Lettre de motivation -->
                <td>
                    <?php if (!empty($candidature['motivation_letter'])): ?>
                        <a href="<?= htmlspecialchars($candidature['motivation_letter']); ?>" target="_blank">Voir Lettre</a>
                    <?php else: ?>
                        Non fourni
                    <?php endif; ?>
                </td>

                <!-- CV -->
                <td>
                    <?php if (!empty($candidature['cv_path'])): ?>
                        <a href="<?= htmlspecialchars($candidature['cv_path']); ?>" target="_blank">Voir CV</a>
                    <?php else: ?>
                        Non fourni
                    <?php endif; ?>
                </td>

                <!-- Entreprise -->
                <td><?= htmlspecialchars($candidature['company_name'] ?? 'Non renseigné'); ?></td>

                <!-- Date de candidature -->
                <td><?= htmlspecialchars($candidature['date_candidature'] ?? ''); ?></td>

                <!-- Actions -->
                <td>
                    <div class="action-pill">
                        <?php 
                        // ADMIN et ETUDIANT peuvent retirer la candidature
                        if ($userRole === 'ADMIN' || $userRole === 'ETUDIANT'): ?>
                            <div class="action-part remove"
                                 onclick="if(confirm('Voulez-vous retirer cette candidature ?')) {
                                     window.location.href='index.php?controller=candidature&action=remove&id=<?= htmlspecialchars($candidature['candidature_id'] ?? ''); ?>';
                                 }">
                                <!-- Icône corbeille -->
                                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9 3v1H4v2h16V4h-5V3c0-.55-.45-1-1-1h-4c-.55 0-1 .45-1 1zM6 8v13c0 1.65 1.35 3 3 3h6c1.65 0 3-1.35 3-3V8H6z" fill="#CF63F0"/>
                                </svg>
                                <span class="tooltip">Retirer</span>
                            </div>
                        <?php elseif ($userRole === 'PILOTE'): ?>
                            <!-- Pour le PILOTE, aucune action n'est autorisée -->
                            <div class="action-part no-action">
                                <span class="no-action-text">-</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Pagination -->
<div class="pagination">
  <?php if ($page > 1): ?>
    <a href="index.php?controller=candidature&action=index&page=<?= $page - 1 ?>&search=<?= urlencode($search ?? '') ?>">Précédent</a>
  <?php endif; ?>

  <?php for ($i = 1; $i <= $totalPages; $i++): ?>
    <?php if ($i == $page): ?>
      <strong><?= $i ?></strong>
    <?php else: ?>
      <a href="index.php?controller=candidature&action=index&page=<?= $i ?>&search=<?= urlencode($search ?? '') ?>"><?= $i ?></a>
    <?php endif; ?>
  <?php endfor; ?>

  <?php if ($page < $totalPages): ?>
    <a href="index.php?controller=candidature&action=index&page=<?= $page + 1 ?>&search=<?= urlencode($search ?? '') ?>">Suivant</a>
  <?php endif; ?>
</div>




<?php include "app/Views/layout/footer.php"; ?>
