<?php
// postuler.php
// On suppose que vous êtes dans "app/Views/candidature/postuler.php"
// et que votre contrôleur vous passe les variables $offers et $error (éventuellement).

include "app/Views/layout/header.php";  // Insertion du header global

?>

<!-- ================================ 
     Style inline pour la page Postuler
     ================================ -->
<style>
/* ====== RESET & BASE ====== */
* {
  margin: 0; 
  padding: 0; 
  box-sizing: border-box;
  font-family: Arial, sans-serif;
}

body {
  background-color: #131313; /* Fond sombre */
  color: #fff;
  min-height: 100vh;
}

/* ====== Conteneur principal ====== */
.candidature-container {
  background-color: #1F1F1F;
  border: 1px solid #323D4E;
  border-radius: 8px;
  padding: 20px;
  max-width: 600px;
  margin: 40px auto; /* Centre horizontalement */
}

/* Titre du formulaire */
.form-title {
  font-size: 1.8rem;
  font-weight: 600;
  margin-bottom: 1rem;
  text-align: center;
}

/* Message d'erreur */
.error-message {
  text-align: center;
  margin-bottom: 1rem;
  color: #ff4d4d;
}

/* Offre pré-sélectionnée */
.offer-selected {
  margin-bottom: 1rem;
  font-size: 1rem;
  color: #ccc;
}

/* Le formulaire principal */
.postuler-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

/* Groupes de champs */
.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
}

/* Label "Offre :" ou "CV :" */
.form-label {
  font-size: 0.9rem;
  color: #ccc;
}

/* Champ texte (recherche d'offre) */
.input-field {
  background-color: #323D4E;
  border: 1px solid #444;
  border-radius: 5px;
  padding: 0.6rem;
  color: #fff;
  font-size: 1rem;
}
.input-field:focus {
  background-color: #3A4049;
}

/* ====== Beau bouton pour input:file ====== */
.file-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background-color: #323D4E;
  border: 1px solid #444;
  border-radius: 5px;
  color: #fff;
  padding: 0.5rem 1rem;
  cursor: pointer;
  transition: background-color 0.2s ease;
  font-size: 0.9rem;
  text-decoration: none;
}
.file-btn i {
  font-size: 1rem;
  color: #FF43DD; /* Couleur rose */
}
.file-btn:hover {
  background-color: #3A4049;
}
.file-btn input[type="file"] {
  display: none;
}

/* Nom du fichier choisi */
.file-chosen {
  margin-top: 0.3rem;
  font-size: 0.85rem;
  color: #ccc;
  font-style: italic;
}

/* ====== Boutons d'action (Submit, Retour) ====== */
.actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end; 
  margin-top: 1rem;
}
.btn-submit,
.btn-back {
  text-decoration: none;
  border: 1px solid #FF43DD; 
  background-color: #1A1A1A;
  color: #FF43DD;
  padding: 0.6rem 1.2rem;
  border-radius: 20px;
  font-size: 1rem;
  transition: background-color 0.2s ease;
  text-align: center;
  cursor: pointer;
}
.btn-submit:hover,
.btn-back:hover {
  background-color: #FF43DD;
  color: #1A1A1A;
}
</style>

<!-- Optionnel: Font Awesome pour l'icône upload -->
<link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
  integrity="sha512-6ox6S49tv8GAbJeGajm40nEG1TPM9s5cBTEz9T9B8sSshDZz6SfZg13r8l7KaZ7dBlxmwQODopHP+r6XxP4rQ=="
  crossorigin="anonymous"
  referrerpolicy="no-referrer"
/>

<div class="candidature-container">
  <?php
  // Définir le titre du formulaire selon le rôle
  $titleText = "Postuler à une offre";
  if (isset($_SESSION['user']) && strtoupper($_SESSION['user']['role']) === 'ADMIN') {
    $titleText = "Ajouter une candidature";
  }

  // Vérifier si un offer_id est passé en GET
  $preselectedOfferId = $_GET['offer_id'] ?? '';

  // Rechercher le titre de l'offre pré-sélectionnée si disponible
  $selectedOfferTitle = '';
  if ($preselectedOfferId && isset($offers) && is_array($offers)) {
    foreach ($offers as $offer) {
      if ($offer['offer_id'] == $preselectedOfferId) {
        $selectedOfferTitle = $offer['title'];
        break;
      }
    }
  }
  ?>

  <h2 class="form-title"><?= htmlspecialchars($titleText); ?></h2>

  <?php if (isset($error)): ?>
    <p class="error-message"><?= htmlspecialchars($error); ?></p>
  <?php endif; ?>

  <form 
    method="post"
    action="index.php?controller=candidature&action=postuler"
    enctype="multipart/form-data"
    class="postuler-form"
  >
    <?php if ($preselectedOfferId): ?>
      <!-- Offre déjà pré-sélectionnée -->
      <input type="hidden" name="offer_id" value="<?= htmlspecialchars($preselectedOfferId); ?>">
      <p class="offer-selected">
        <strong>Offre sélectionnée :</strong>
        <?= $selectedOfferTitle ? htmlspecialchars($selectedOfferTitle) : htmlspecialchars($preselectedOfferId); ?>
      </p>
    <?php else: ?>
      <!-- Recherche d'offre via input + datalist -->
      <div class="form-group">
        <label for="offerSearch" class="form-label">Offre :</label>
        <input 
          type="text"
          id="offerSearch"
          list="offersList"
          placeholder="Rechercher une offre..."
          required
          class="input-field"
        />
        <datalist id="offersList">
          <?php if (isset($offers) && is_array($offers)): ?>
            <?php foreach($offers as $offer): ?>
              <option value="<?= htmlspecialchars($offer['title']); ?>">
            <?php endforeach; ?>
          <?php endif; ?>
        </datalist>
        <input type="hidden" name="offer_id" id="offerId">
      </div>

      <script>
        // On récupère la liste des offres
        const offers = <?php echo isset($offers) ? json_encode($offers) : '[]'; ?>;
        document.getElementById("offerSearch").addEventListener("change", function() {
          const val = this.value.trim().toLowerCase();
          const found = offers.find(o => o.title.toLowerCase() === val);
          document.getElementById("offerId").value = found ? found.offer_id : "";
        });
      </script>
    <?php endif; ?>

    <!-- Button "Sélectionner un fichier" pour la lettre de motivation -->
    <div class="form-group">
      <label class="form-label">Lettre de motivation (PDF) :</label>
      <label class="file-btn">
        <i class="fas fa-file-upload"></i> Sélectionner un fichier
        <input
          type="file"
          name="motivation_letter"
          id="motivation_letter"
          accept="application/pdf"
          required
          onchange="updateFileName('motivationDisplay', this)"
        />
      </label>
      <p class="file-chosen" id="motivationDisplay">Aucun fichier choisi</p>
    </div>

    <!-- Button "Sélectionner un fichier" pour le CV -->
    <div class="form-group">
      <label class="form-label">CV (PDF) :</label>
      <label class="file-btn">
        <i class="fas fa-file-upload"></i> Sélectionner un fichier
        <input
          type="file"
          name="cv"
          id="cv"
          accept="application/pdf"
          required
          onchange="updateFileName('cvDisplay', this)"
        />
      </label>
      <p class="file-chosen" id="cvDisplay">Aucun fichier choisi</p>
    </div>

    <div class="actions">
      <button type="submit" class="btn-submit"><?= htmlspecialchars($titleText); ?></button>
      <a href="index.php?controller=candidature&action=index" class="btn-back">Retour</a>
    </div>
  </form>
</div>

<!-- Petit script pour afficher le nom du fichier -->
<script>
function updateFileName(displayId, fileInput) {
  const displayElem = document.getElementById(displayId);
  if (fileInput.files && fileInput.files.length > 0) {
    displayElem.textContent = fileInput.files[0].name;
  } else {
    displayElem.textContent = 'Aucun fichier choisi';
  }
}
</script>

<?php include "app/Views/layout/footer.php"; ?>
