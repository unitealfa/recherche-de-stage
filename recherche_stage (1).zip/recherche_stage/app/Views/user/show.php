<?php include "app/Views/layout/header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Profil Utilisateur</title>
  <link rel="stylesheet" type="text/css" href="public/css/UserShow.css">
</head>
<body>

  <div class="profile-container">
    <h2>Profil Utilisateur</h2>

    <div class="profile-picture">
      <img src="<?= !empty($user['profile_picture']) ? $user['profile_picture'] : 'public/uploads/profile_pictures/defaultpfpuser.jpg'; ?>" alt="Profile Picture">
    </div>

    <div class="profile-info">
      <div class="info-group">
        <label>Prénom</label>
        <p><?= htmlspecialchars($user['first_name']); ?></p>
      </div>

      <div class="info-group">
        <label>Nom</label>
        <p><?= htmlspecialchars($user['last_name']); ?></p>
      </div>

      <div class="info-group">
        <label>Email</label>
        <p><?= htmlspecialchars($user['email']); ?></p>
      </div>

      <div class="info-group">
        <label>Rôle</label>
        <p><?= htmlspecialchars($user['role']); ?></p>
      </div>
    </div>
  </div>

  <!-- Bouton SVG retour -->
  <div class="return-btn" onclick="history.back()">
    <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="48" height="48" fill="white" fill-opacity="0.01"/>
      <path fill-rule="evenodd" clip-rule="evenodd" d="M44 40.8361C39.1069 34.8632 34.7617 31.4739 30.9644 30.6682C27.1671 29.8625 23.5517 29.7408 20.1182 30.303V41L4 23.5453L20.1182 7V17.167C26.4667 17.2172 31.8638 19.4948 36.3095 24C40.7553 28.5052 43.3187 34.1172 44 40.8361Z" fill="#FF43DD" stroke="#000000" stroke-width="4" stroke-linejoin="round"/>
    </svg>
  </div>

</body>
</html>

<?php include "app/Views/layout/footer.php"; ?>
