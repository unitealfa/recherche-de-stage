<?php include "app/Views/layout/header.php"; ?>

<link rel="stylesheet" type="text/css" href="Public/css/UserCreate.css">

<h2>Create A New User Account</h2>
<?php if(isset($error)): ?>
  <p style="color:red;"><?= $error; ?></p>
<?php endif; ?>

<div class="form-container">
  <div class="image-upload">
    <input type="file" name="profile_picture" accept="image/*" id="profile_picture_input" style="display: none;">
    <div class="preview" style="background-image: url('');"></div>
    <label for="profile_picture_input" style="cursor: pointer;">Upload Photo</label>
  </div>

  <div class="form-fields">
    <form method="post" action="index.php?controller=user&action=create" enctype="multipart/form-data">
      <div class="form-group-row">
        <div class="form-group">
          <label>First Name</label>
          <input type="text" name="first_name" placeholder="Enter the first name" required>
        </div>

        <div class="form-group">
          <label>Last Name</label>
          <input type="text" name="last_name" placeholder="Enter the last name" required>
        </div>
      </div>

      <div class="form-group-row">
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" placeholder="Enter the email" required>
        </div>

        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" placeholder="Enter the password" required>
        </div>
      </div>

      <?php if (strtoupper($_SESSION['user']['role']) === 'ADMIN'): ?>
      <div class="form-group">
        <label>Role</label>
        <select name="role">
          <option value="ETUDIANT">Étudiant</option>
          <option value="PILOTE">Pilote</option>
          <option value="ADMIN">Admin</option>
        </select>
      </div>
      <?php endif; ?>

      <div class="form-actions">
        <button type="submit">Add New</button>
      </div>
    </form>
  </div>
</div>



<?php include "app/Views/layout/footer.php"; ?>
