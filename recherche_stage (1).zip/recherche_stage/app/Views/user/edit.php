<?php include "app/Views/layout/header.php"; ?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Modifier l'utilisateur</title>
  <link rel="stylesheet" type="text/css" href="Public/css/UserEdit.css">
</head>
<body>

<h2>Edit User Account</h2>

<?php if(isset($error)): ?>
  <p style="color:red;"><?= htmlspecialchars($error); ?></p>
<?php endif; ?>

<div class="form-container">
  <form method="post" action="index.php?controller=user&action=edit" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $user['user_id']; ?>">
    
    <div class="image-upload">
      <input type="file" name="profile_picture" accept="image/*" id="profile_picture_input" style="display: none;">
      <div class="preview" style="background-image: url('<?= !empty($user['profile_picture']) ?$user['profile_picture'] : 'public/uploads/profile_pictures/defaultpfpuser.jpg'; ?>')"></div>
      <label for="profile_picture_input" style="cursor: pointer;">Upload Photo</label>
    </div>

    <div class="form-fields">
      <div class="form-group-row">
        <div class="form-group">
          <label>First Name</label>
          <input type="text" name="first_name" value="<?= htmlspecialchars($user['first_name']); ?>" required>
        </div>

        <div class="form-group">
          <label>Last Name</label>
          <input type="text" name="last_name" value="<?= htmlspecialchars($user['last_name']); ?>" required>
        </div>
      </div>

      <div class="form-group-row">
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>
        </div>

        <div class="form-group">
          <label>Role</label>
          <select name="role">
            <option value="ETUDIANT" <?= ($user['role'] === 'ETUDIANT') ? 'selected' : ''; ?>>Étudiant</option>
            <option value="PILOTE" <?= ($user['role'] === 'PILOTE') ? 'selected' : ''; ?>>Pilote</option>
            <option value="ADMIN" <?= ($user['role'] === 'ADMIN') ? 'selected' : ''; ?>>Admin</option>
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button type="submit">Update</button>
      </div>
    </div>
  </form>
</div>

<div class="return-btn" onclick="history.back()">
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" fill="white" fill-opacity="0.01"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M44 40.8361C39.1069 34.8632 34.7617 31.4739 30.9644 30.6682C27.1671 29.8625 23.5517 29.7408 20.1182 30.303V41L4 23.5453L20.1182 7V17.167C26.4667 17.2172 31.8638 19.4948 36.3095 24C40.7553 28.5052 43.3187 34.1172 44 40.8361Z" fill="#FF43DD" stroke="#000000" stroke-width="4" stroke-linejoin="round"/>
  </svg>
</div>

<?php include "app/Views/layout/footer.php"; ?>
