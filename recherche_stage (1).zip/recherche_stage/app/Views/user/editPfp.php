<?php include "app/Views/layout/header.php"; ?>

<style>
    /* ====== RESET ====== */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: Arial, sans-serif;
}

body {
  background-color: #131313; 
  color: #fff;
  min-height: 100vh;
  /* On ne change pas la structure, tu peux conserver le style du header */
  /* Seules classes pour la page de pfp */
}

.profile-container {
  background-color: #1F1F1F;
  border: 1px solid #323D4E;
  border-radius: 8px;
  padding: 30px;
  max-width: 400px;
  width: 100%;
  margin: 40px auto; /* or keep if you'd like it centered differently */
  position: relative;
}

.profile-container h1 {
  font-size: 1.6rem;
  font-weight: 600;
  margin-bottom: 20px;
  text-align: center;
  color: #fff;
}

.error-message {
  text-align: center;
  margin-bottom: 10px;
  color: #ff4d4d;
}

/* Aperçu avatar actuel */
.avatar-preview {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}
.avatar-preview img {
  width: 100px; 
  height: 100px; 
  border-radius: 50%;
  object-fit: cover;
}

/* Zone Drag & Drop */
.dropzone {
  position: relative;
  border: 2px dashed #FF43DD; /* rose */
  border-radius: 8px;
  padding: 40px;
  text-align: center;
  cursor: pointer;
  transition: background-color 0.2s ease;
  margin-bottom: 20px;
}
.dropzone:hover {
  background-color: #2C2C2C;
}
.dropzone p {
  color: #bbb;
  font-size: 0.9rem;
  white-space: pre-line;
}
.dropzone input[type="file"] {
  position: absolute;
  top: 0; 
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
  cursor: pointer;
}
.dropzone.highlight {
  background-color: #333333;
  border-color: #FF77EE;
}

/* Boutons */
.actions {
  display: flex;
  gap: 1rem;
  justify-content: center;
  margin-top: 10px;
}
.btn-submit,
.btn-back {
  text-decoration: none;
  border: 1px solid #FF43DD;
  background-color: #1a1a1a;
  color: #FF43DD;
  padding: 0.6rem 1.2rem;
  border-radius: 20px;
  font-size: 1rem;
  transition: background-color 0.2s ease;
  text-align: center;
  cursor: pointer;
}
.btn-submit:hover,
.btn-back:hover {
  background-color: #FF43DD;
  color: #1a1a1a;
}

</style>
<div class="profile-container">
  <h1>Modifier la Photo de Profil</h1>

  <?php if(isset($error)): ?>
    <p class="error-message"><?= htmlspecialchars($error); ?></p>
  <?php endif; ?>

  <!-- Formulaire avec drag & drop / preview -->
  <form 
    method="post" 
    action="index.php?controller=user&action=updatePfp" 
    enctype="multipart/form-data"
    id="profileForm"
  >
    <!-- On passe l'ID de l'utilisateur (ici, $user['user_id']) -->
    <input type="hidden" name="id" value="<?= htmlspecialchars($user['user_id'] ?? '') ?>">

    <!-- Aperçu de l'avatar actuel -->
    <div class="avatar-preview">
      <?php if (!empty($user['profile_picture'])): ?>
        <img 
          id="previewImg"
          src="<?= htmlspecialchars($user['profile_picture']); ?>" 
          alt="Photo de profil"
        />
      <?php else: ?>
        <img 
          id="previewImg"
          src="public/uploads/profile_pictures/defaultpfpuser.jpg" 
          alt="Photo de profil"
        />
      <?php endif; ?>
    </div>

    <!-- Zone drag & drop + input file invisible -->
    <div class="dropzone" id="dropzone">
      <p id="dropzoneText">
Glissez-déposez la nouvelle photo ici
ou cliquez pour la sélectionner
      </p>
      <input 
        type="file"
        name="profile_picture"
        id="profile_picture"
        accept="image/*"
      />
    </div>

    <div class="actions">
      <button type="submit" name="submit" class="btn-submit">Modifier</button>
      <!-- Bouton/lien Retour menant à la vue précédente -->
      <a href="index.php?controller=user&action=index" class="btn-back">Retour</a>
    </div>
  </form>
</div>

<!-- Script pour le drag & drop et la preview -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  const dropzone = document.getElementById('dropzone');
  const fileInput = document.getElementById('profile_picture');
  const dropzoneText = document.getElementById('dropzoneText');
  const previewImg = document.getElementById('previewImg');

  let justDropped = false; // Evite l'ouverture de la fenêtre après drop

  // Empêche ouverture du fichier dans le navigateur
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropzone.addEventListener(eventName, e => {
      e.preventDefault();
      e.stopPropagation();
    });
  });

  // Survol
  ['dragenter', 'dragover'].forEach(eventName => {
    dropzone.addEventListener(eventName, () => {
      dropzone.classList.add('highlight');
      dropzoneText.textContent = 'Déposez l\'image pour la charger';
    });
  });

  // Quitte la zone
  ['dragleave', 'drop'].forEach(eventName => {
    dropzone.addEventListener(eventName, () => {
      dropzone.classList.remove('highlight');
      dropzoneText.textContent = 'Glissez-déposez la nouvelle photo ici\nou cliquez pour la sélectionner';
    });
  });

  // Drop
  dropzone.addEventListener('drop', e => {
    const files = e.dataTransfer.files;
    if (files.length) {
      fileInput.files = files;   // Assigne le fichier
      previewFile(files[0]);     // Preview
      justDropped = true;        // Note qu'on a fait un drop
      // Petit délai pour éviter le clic fantôme
      setTimeout(() => { justDropped = false }, 50);
    }
  });

  // Clic => ouvre la fenêtre, sauf si on vient de drop
  dropzone.addEventListener('click', e => {
    if (justDropped) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    fileInput.click();
  });

  // Si on choisit un fichier via la fenêtre => preview
  fileInput.addEventListener('change', () => {
    if (fileInput.files && fileInput.files[0]) {
      previewFile(fileInput.files[0]);
    }
  });

  function previewFile(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      previewImg.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
});

</script>

<?php include "app/Views/layout/footer.php"; ?>
