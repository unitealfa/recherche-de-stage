<?php
// app/Controllers/UserController.php
require_once "app/Controllers/BaseController.php";
require_once "app/Models/User.php";

class UserController extends BaseController {
    private $db;

    public function __construct($db) {
        $this->db = $db;
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    // =========================================
    // Liste des utilisateurs (ADMIN/PILOTE)
    // =========================================
    public function index() {
        $this->requireRole(['ADMIN', 'PILOTE']);
        
        $search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING) ?: '';
        $currentUserRole = strtoupper($_SESSION['user']['role'] ?? '');
        
        $limit = 10;
        $page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, [
            'options' => ['default' => 1, 'min_range' => 1]
        ]);
        $offset = ($page - 1) * $limit;
        
        $userModel = new User($this->db);

        if (!empty($search)) {
            if ($currentUserRole === 'PILOTE') {
                // Pilote => seulement les comptes étudiants
                $allUsers = $userModel->searchByNameOrEmailAndRole($search, 'ETUDIANT');
            } else {
                // Admin => tous comptes
                $allUsers = $userModel->searchByNameOrEmail($search);
            }
            $totalUsers = count($allUsers);
            $users = array_slice($allUsers, $offset, $limit);
        } else {
            // Pas de recherche
            if ($currentUserRole === 'PILOTE') {
                // Pilote => seulement étudiants
                $allUsers = $userModel->getAllEtudiants();
                $totalUsers = count($allUsers);
                $users = array_slice($allUsers, $offset, $limit);
            } else {
                // Admin => tout
                $users = $userModel->getUsersWithLimit($limit, $offset);
                $totalUsers = $userModel->getTotalUsers();
            }
        }
        
        $totalPages = ceil($totalUsers / $limit);
        include "app/Views/user/index.php";
    }

    // =========================================
    // Afficher un utilisateur (ADMIN/PILOTE)
    // =========================================
    public function show() {
        $this->requireRole(['ADMIN', 'PILOTE']);
        $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if (!$id) {
            header("Location: index.php?controller=user&action=index");
            exit;
        }
        $userModel = new User($this->db);
        $user = $userModel->findById($id);
        include "app/Views/user/show.php";
    }

    // =========================================
    // Créer un utilisateur (ADMIN/PILOTE)
    // =========================================
    public function create() {
        $this->requireRole(['ADMIN', 'PILOTE']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $first_name = trim(filter_input(INPUT_POST, 'first_name', FILTER_SANITIZE_STRING) ?: '');
            $last_name  = trim(filter_input(INPUT_POST, 'last_name', FILTER_SANITIZE_STRING) ?: '');
            $email      = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?: '');
            $password   = $_POST['password'] ?? '';

            // Valider l'email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Adresse email invalide.";
                include "app/Views/user/create.php";
                return;
            }

            // Rôle : si Admin, on prend le 'role' de POST, sinon imposer ETUDIANT
            if (strtoupper($_SESSION['user']['role']) === 'ADMIN') {
                $role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING) ?: 'ETUDIANT';
            } else {
                $role = 'ETUDIANT';
            }

            if (empty($password)) {
                $error = "Mot de passe requis.";
                include "app/Views/user/create.php";
                return;
            }

            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $userModel = new User($this->db);
            $result = $userModel->create($first_name, $last_name, $email, $password_hash, $role);

            if ($result) {
                header("Location: index.php?controller=user&action=index");
                exit;
            } else {
                $error = "Erreur lors de la création du compte.";
            }
        }

        include "app/Views/user/create.php";
    }

    // =========================================
    // Modifier un utilisateur (ADMIN/PILOTE)
    // =========================================
    public function edit() {
        $this->requireRole(['ADMIN', 'PILOTE']);
        $userModel = new User($this->db);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
            $first_name = trim(filter_input(INPUT_POST, 'first_name', FILTER_SANITIZE_STRING) ?: '');
            $last_name  = trim(filter_input(INPUT_POST, 'last_name', FILTER_SANITIZE_STRING) ?: '');
            $email      = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?: '');
            $role       = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING) ?: 'ETUDIANT';

            // Valider l'email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Adresse email invalide.";
                include "app/Views/user/edit.php";
                return;
            }

            // Si c'est un pilote, imposer le rôle ETUDIANT
            if ($_SESSION['user']['role'] === 'PILOTE') {
                $role = 'ETUDIANT';
            }

            // Gérer l'upload d'une pfp (facultatif)
            $profilePicture = null;
            if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
                $fileTmpPath   = $_FILES['profile_picture']['tmp_name'];
                $fileName      = $_FILES['profile_picture']['name'];
                $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

                $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($fileExtension, $allowedExtensions)) {
                    $uploadDir = 'public/uploads/profile_pictures/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }
                    $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                    $destPath = $uploadDir . $newFileName;
                    if (move_uploaded_file($fileTmpPath, $destPath)) {
                        $profilePicture = $destPath;
                    }
                }
            }

            $result = $userModel->update($id, $first_name, $last_name, $email, $role, $profilePicture);
            if ($result) {
                // Mettre à jour la session si on modifie son propre compte
                if ($_SESSION['user']['user_id'] == $id && $profilePicture !== null) {
                    $_SESSION['user']['profile_picture'] = $profilePicture;
                }
                header("Location: index.php?controller=user&action=index");
                exit;
            } else {
                $error = "Erreur lors de la modification.";
            }
        } else {
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            if (!$id) {
                header("Location: index.php?controller=user&action=index");
                exit;
            }
            $user = $userModel->findById($id);
        }
        include "app/Views/user/edit.php";
    }

    // =========================================
    // Supprimer un utilisateur (ADMIN/PILOTE)
    // =========================================
    public function delete() {
        $this->requireRole(['ADMIN', 'PILOTE']);
        $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if ($id) {
            $userModel = new User($this->db);
            $userModel->delete($id);
        }
        header("Location: index.php?controller=user&action=index");
        exit;
    }

    // =========================================
    // Editer la photo de profil => ADMIN/PILOTE/ETUDIANT
    // =========================================
    public function editPfp() {
        // Autoriser tous les rôles connectés
        $this->requireRole(['ADMIN', 'PILOTE', 'ETUDIANT']);

        // Récupérer l'utilisateur connecté
        $userModel = new User($this->db);
        $userId = $_SESSION['user']['user_id'];
        $user = $userModel->findById($userId);

        include "app/Views/user/editPfp.php";
    }

    // =========================================
    // Mettre à jour la photo de profil
    // =========================================
    public function updatePfp() {
        // Autoriser ADMIN, PILOTE, ETUDIANT
        $this->requireRole(['ADMIN', 'PILOTE', 'ETUDIANT']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userId = $_POST['id'] ?? 0;
            $fileError = $_FILES['profile_picture']['error'] ?? null;

            if (isset($_FILES['profile_picture']) && $fileError === UPLOAD_ERR_OK) {
                $fileTmpPath   = $_FILES['profile_picture']['tmp_name'];
                $fileName      = $_FILES['profile_picture']['name'];
                $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                
                $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

                if (in_array($fileExtension, $allowedExtensions)) {
                    $uploadDir   = 'public/uploads/profile_pictures/';
                    $newFileName = 'user_' . $userId . '_' . time() . '.' . $fileExtension;
                    $destPath    = $uploadDir . $newFileName;

                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }

                    if (move_uploaded_file($fileTmpPath, $destPath)) {
                        $userModel = new User($this->db);
                        $ok = $userModel->updateProfilePicture($userId, $destPath);
                        if ($ok) {
                            // Mettre à jour la session si c'est le user connecté
                            if ($_SESSION['user']['user_id'] == $userId) {
                                $_SESSION['user']['profile_picture'] = $destPath;
                            }

                            // Déterminer la redirection selon le rôle
                            $currentUserRole = strtoupper($_SESSION['user']['role'] ?? '');
                            if ($currentUserRole === 'ADMIN' || $currentUserRole === 'PILOTE') {
                                // Admin/Pilote => liste user
                                header("Location: index.php?controller=user&action=index");
                            } else {
                                // Étudiant => par ex. dashboard
                                header("Location: index.php?controller=dashboard&action=etudiant");
                            }
                            exit;
                        } else {
                            $error = "Erreur lors de la mise à jour en base.";
                        }
                    } else {
                        $error = "Erreur lors du déplacement du fichier.";
                    }
                } else {
                    $error = "Extension non autorisée (jpg, jpeg, png, gif).";
                }
            } else {
                $error = "Aucun fichier sélectionné ou erreur d'upload.";
            }
        }

        // En cas d'erreur ou pas POST => on réaffiche la vue
        $userModel = new User($this->db);
        $userId = $_SESSION['user']['user_id'];
        $user = $userModel->findById($userId);
        include "app/Views/user/editPfp.php";
    }
}
