<?php
// app/Models/Candidature.php

class Candidature {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    // Créer une candidature
    public function create($user_id, $offer_id, $date_candidature, $cv_path, $motivationLetterPath, $candidateName) {
        $sql = "INSERT INTO candidatures (user_id, offer_id, date_candidature, cv_path, motivation_letter, candidate_name) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$user_id, $offer_id, $date_candidature, $cv_path, $motivationLetterPath, $candidateName]);
    }
    
    // Récupérer les candidatures pour un utilisateur spécifique
    public function getByUserId($user_id) {
        $sql = "SELECT c.candidature_id,
                       c.user_id,
                       c.offer_id,
                       c.date_candidature,
                       c.cv_path,
                       c.motivation_letter,
                       u.first_name,
                       u.last_name,
                       o.title AS offer_title,
                       comp.name AS company_name
                FROM candidatures c
                INNER JOIN users u       ON c.user_id = u.user_id
                INNER JOIN offers o      ON c.offer_id = o.offer_id
                INNER JOIN companies comp ON o.company_id = comp.company_id
                WHERE c.user_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Récupère toutes les candidatures en joignant `users`, `offers` et `companies`.
     * Permet d'afficher :
     * - Le nom du candidat (first_name + last_name),
     * - Le titre de l'offre (offer_title),
     * - Le nom de l'entreprise (company_name).
     */
    public function getAllWithCandidateOfferAndCompany() {
        $sql = "SELECT c.candidature_id,
                       c.user_id,
                       c.offer_id,
                       c.date_candidature,
                       c.cv_path,
                       c.motivation_letter,
                       CONCAT(u.first_name, ' ', u.last_name) AS candidate_name,
                       o.title AS offer_title,
                       comp.name AS company_name
                FROM candidatures c
                INNER JOIN users u       ON c.user_id = u.user_id
                INNER JOIN offers o      ON c.offer_id = o.offer_id
                INNER JOIN companies comp ON o.company_id = comp.company_id";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Trouver une candidature par son ID
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM candidatures WHERE candidature_id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Mettre à jour la lettre de motivation d'une candidature
    public function update($candidature_id, $motivation_letter) {
        $stmt = $this->db->prepare("UPDATE candidatures SET motivation_letter = ? WHERE candidature_id = ?");
        return $stmt->execute([$motivation_letter, $candidature_id]);
    }
    
    // Supprimer une candidature
    public function delete($candidature_id) {
        $stmt = $this->db->prepare("DELETE FROM candidatures WHERE candidature_id = ?");
        return $stmt->execute([$candidature_id]);
    }
    
    // =======================================================
    // Méthodes de pagination
    // =======================================================
    
    // Récupère le nombre total de candidatures (pour ADMIN/PILOTE)
    public function getTotalCandidatures() {
        $sql = "SELECT COUNT(*) as total FROM candidatures";
        $stmt = $this->db->query($sql);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'];
    }
    
    // Récupère le nombre total de candidatures pour un utilisateur spécifique (ETUDIANT)
    public function getTotalCandidaturesByUserId($user_id) {
        $sql = "SELECT COUNT(*) as total FROM candidatures WHERE user_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'];
    }
    
    // Récupère les candidatures avec jointures et paginées (pour ADMIN/PILOTE)
    public function getAllWithCandidateOfferAndCompanyWithLimit($limit, $offset) {
        $sql = "SELECT c.candidature_id,
                       c.user_id,
                       c.offer_id,
                       c.date_candidature,
                       c.cv_path,
                       c.motivation_letter,
                       CONCAT(u.first_name, ' ', u.last_name) AS candidate_name,
                       o.title AS offer_title,
                       comp.name AS company_name
                FROM candidatures c
                INNER JOIN users u       ON c.user_id = u.user_id
                INNER JOIN offers o      ON c.offer_id = o.offer_id
                INNER JOIN companies comp ON o.company_id = comp.company_id
                ORDER BY c.date_candidature DESC
                LIMIT ? OFFSET ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(1, (int)$limit, PDO::PARAM_INT);
        $stmt->bindValue(2, (int)$offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Récupère les candidatures paginées pour un utilisateur spécifique (ETUDIANT)
    public function getByUserIdWithLimit($user_id, $limit, $offset) {
        $sql = "SELECT c.candidature_id,
                       c.user_id,
                       c.offer_id,
                       c.date_candidature,
                       c.cv_path,
                       c.motivation_letter,
                       CONCAT(u.first_name, ' ', u.last_name) AS candidate_name,
                       o.title AS offer_title,
                       comp.name AS company_name
                FROM candidatures c
                INNER JOIN users u       ON c.user_id = u.user_id
                INNER JOIN offers o      ON c.offer_id = o.offer_id
                INNER JOIN companies comp ON o.company_id = comp.company_id
                WHERE c.user_id = ?
                ORDER BY c.date_candidature DESC
                LIMIT ? OFFSET ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(1, $user_id, PDO::PARAM_INT);
        $stmt->bindValue(2, (int)$limit, PDO::PARAM_INT);
        $stmt->bindValue(3, (int)$offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>